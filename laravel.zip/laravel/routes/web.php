<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/ulist', 'UserList@index')->name('users');
Route::get('/admin', 'AdminController@index');
//Route::get('/lc/listing/add', 'ListingConciergeController@ListingConc');
//Route::post('/lc/listing/add', ['as'=>'listing_data.store','uses'=>'ListingConciergeController@ListingConcPost']);


Route::get('/lc/listing/add', [
    'uses' => 'ListingConciergeController@create',
    'as' => 'listing.create'
]);

Route::get('/listings', [
    'uses' => 'ListingConciergeController@store',
    'as' => 'listing.list'
]);

Route::post('listings', [
    'uses' => 'ListingConciergeController@store',
    'as' => 'listing.store'
]);