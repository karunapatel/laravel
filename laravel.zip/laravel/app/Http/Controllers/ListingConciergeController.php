<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\ListingConcierge;
use Illuminate\Routing\Controller as BaseController;
use Kris\LaravelFormBuilder\FormBuilder;
use App\Forms\ListingAddForm;

class ListingConciergeController extends BaseController {

    public function create(FormBuilder $formBuilder)
    {
        $form = $formBuilder->create(ListingAddForm::class, [
            'method' => 'POST',
            'url' => route('listing.store')
        ]);

        return view('listing.create', compact('form'));
    }

    public function store(FormBuilder $formBuilder, Request $request)
    {
        $form = $formBuilder->create(ListingAddForm::class);

        if (!$form->isValid()) {
            return redirect()->back()->withErrors($form->getErrors())->withInput();
        }
        else {
        // Do saving and other things...
          $lc = new ListingConcierge;
          $lc->id = $request->input('id');
          $lc->title = $request->input('title');
          $lc->description = $request->input('description');
          $lc->agent_name = $request->input('agent_name');
          $lc->primary_agent = $request->input('primary_agent');
          $lc->street = $request->input('street');
          $lc->unit_number = $request->input('unit_number');
          $lc->city = $request->input('city');
          $lc->state = $request->input('state');
          $lc->zip = $request->input('zip');
          $lc->property_type = $request->input('property_type');
          $lc->listing_status = $request->input('listing_status');
          $lc->hide_listing = $request->input('hide_listing');
          $lc->list_price = $request->input('list_price');
          $lc->bedrooms = $request->input('bedrooms');
          $lc->bathrooms = $request->input('bathrooms');
          $lc->sqft = $request->input('sqft');
          $lc->lot_sqft = $request->input('lot_sqft');
          $lc->list_date = $request->input('list_date');
          $lc->closed_date = $request->input('closed_date');
          $lc->community = $request->input('community');
          $lc->save();
          
          if($lc){
            echo'<div class="alert alert-success">Listing created successfully !</div>';
            $data = $form->getFieldValues();
            echo'<pre>';
            print_r($data);
            echo'</pre>';
            return view('listing.list')->with('users', $users);
          } else {
            echo'<div class="alert alert-danger">Something went wrong !</div>';
          }
        }
        
        //return view('listing.store', compact('data'));
        return view('listing.list')->with('users', $users);
    }
}