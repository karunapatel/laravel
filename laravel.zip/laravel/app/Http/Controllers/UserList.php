<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserList extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $users = User::all();      // to get all users
        //$users = User::where('id', '!=', auth()->id())->get(); // to get all users except logged in user

       // $headers = ['Name', 'Email'];

       // $users = App\User::all(['name', 'email'])->toArray();

       // $this->table($headers, $users);


        $request->user()->authorizeRoles(['admin']);
        //return view('userlist', compact('users'));            
        //return View('userlist')->with(compact('users'));
        return view('userlist')->with('users', $users);
    }
}
