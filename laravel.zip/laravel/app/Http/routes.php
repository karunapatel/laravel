<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get ('login',function(){
  Return View::make ('login');
});

Route::get('ulist', ['middleware' => 'admin', function(){
  Return View::make('userlist');
}]);

If (Auth::check ()) {
  return Redirect::to('/home');
  }
  return View::make('login');
});

Route::post('logincheck', function(){
  // username and password validation rule
  $rules = array (
    'username' => 'required|max:25',
    'password' => 'required|max:25',
  );
  $v = Validator::make (Input::all (), $rules);
  if ($v->fails()) {
    // username or password missing
    // validation fails
    // used to retain input values
    Input::flash ();
    // return to login page with errors
    return Redirect::to('login')
    ->withInput()
    ->withErrors ($v->messages ());
    } else {
    $userdata = array (
      'username' => Input::get('username'),
      'password' => Input::get('password')
    );
    If (Auth::attempt ($userdata)) {
      // authentication success, enters home page
      return Redirect::to('home');
    } else {
      // authentication fail, back to login page with errors
      return Redirect::to('login')
      ->withErrors('Incorrect login details');
    }
  }
});

Route::get ('logout',function(){
  Auth::logout ();
  return Redirect::to('login');
});