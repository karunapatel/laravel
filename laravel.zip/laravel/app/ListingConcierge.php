<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListingConcierge extends Model
{
    public $table = 'listing_data';
    public $fillable = ['title','description','agent_name','primary_agent','street','unit_number','city','state','zip','property_type','listing_status','hide_listing','list_price','bedrooms','bathrooms','sqft','lot_sqft','list_date','closed_date','community','created_at','updated_at'];
}
