<?php

namespace App\Forms;

use Kris\LaravelFormBuilder\Form;

class ListingAddForm extends Form
{
    public function buildForm()
    {
        $options_half = [
          'wrapper' => ['class' => 'form-group col-sm-6'],
        ];
    
        $options_full = [
          'wrapper' => ['class' => 'form-group col-sm-12'],
        ];
        
        $d_flex = [
          'wrapper' => ['class' => 'form-group col-sm-12 d-flex'],
        ];
        
        $btn_primary = [
          'attr' => ['class' => 'btn btn-primary cb-120 gap_right_15', 'label' => 'Save'],
          'wrapper' => ['class' => 'form-group pull-right'],
        ];
        
        $btn_default = [
          'attr' => ['class' => 'btn btn-default cb-120', 'label' => 'Reset'],
          'wrapper' => ['class' => 'form-group pull-right gap_right_15'],
        ];
        
        $property_type = [
          'wrapper' => ['class' => 'form-group col-sm-6'],
          'choices' => ['commertial' => 'Commertial', 'residential' => 'Residential', 'rental' => 'Rental', 'single family' => 'Single Family', 'multi family' => 'Multi Family'],
          'empty_value' => '--Select Property Type--'
          
        ];
        
        $listing_status = [
          'wrapper' => ['class' => 'form-group col-sm-6'],
          'choices' => ['Active' => 'Active', 'Closed' => 'Closed', 'Contingent' => 'Contingent', 'Inactive' => 'Inactive', 'Pending' => 'Pending'],
          'empty_value' => '--Select Status--'
        ];
      
        $this
            ->add('id', 'hidden', [])
            ->add('title', 'text', $options_full)
            ->add('description', 'textarea', $options_full)
            ->add('agent_name', 'text', $options_full)
            ->add('primary_agent', 'checkbox', $d_flex)
            ->add('street', 'text', $options_half)
            ->add('unit_number', 'text', $options_half)
            ->add('city', 'text', $options_half)
            ->add('state', 'text', $options_half)
            ->add('zip', 'text', $options_half)
            ->add('property_type', 'select', $property_type)
            ->add('listing_status', 'select', $listing_status)
            ->add('hide_listing', 'checkbox', $d_flex)
            ->add('list_price', 'text', $options_half)
            ->add('bedrooms', 'text', $options_half)
            ->add('bathrooms', 'text', $options_half)
            ->add('sqft', 'text', $options_half)
            ->add('lot_sqft', 'text', $options_half)
            ->add('list_date', 'date', $options_half)
            ->add('closed_date', 'date', $options_half)
            ->add('community', 'text', $options_half);
            
        $this
          ->add('submit', 'submit', $btn_primary)
          ->add('clear', 'reset', $btn_default);
    }
}
