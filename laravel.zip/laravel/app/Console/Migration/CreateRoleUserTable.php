<?php
namespace App\Console\Migration;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Migrations\Migrator;

public function up()
{
  Schema::create(‘role_user’, function (Blueprint $table) {
    $table->increments(‘id’);
    $table->integer(‘role_id’)->unsigned();
    $table->integer(‘user_id’)->unsigned();
    $table->timestamps();
  });
}
public function down()
{
  Schema::dropIfExists(‘role_user’);
}