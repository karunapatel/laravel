<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="flex-center">
      <div class="content">
          <h1>Add New Listing</h1>
          <?php if(Session::has('success')): ?>
             <div class="alert alert-success">
               <?php echo e(Session::get('success')); ?>

             </div>
          <?php endif; ?>
          
          <?php echo form($form); ?>

          
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>