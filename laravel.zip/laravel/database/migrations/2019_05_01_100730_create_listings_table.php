<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateListingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::create('listing_data', function (Blueprint $table) { 
        $table->increments('id'); 
        $table->string('title', 150); 
        $table->longText('description'); 
        $table->string('agent_name', 150); 
        $table->boolean('primary_agent'); 
        $table->string('street'); 
        $table->integer('unit_number'); 
        $table->string('city'); 
        $table->string('state'); 
        $table->integer('zip'); 
        $table->enum('property_type', ['Commertial', 'Residential', 'Rental', 'Single Family', 'Multi Family']); 
        $table->enum('listing_status', ['Active', 'Closed', 'Contingent', 'Inactive', 'Pending']); 
        $table->enum('hide_listing', ['Yes', 'No']); 
        $table->float('list_price'); 
        $table->integer('bedrooms'); 
        $table->integer('bathrooms'); 
        $table->integer('sqft'); 
        $table->integer('lot_sqft'); 
        $table->date('list_date'); 
        $table->date('closed_date'); 
        $table->string('community'); 
        $table->timestamps(); 
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
      Schema::drop("listing_data");
    }
}
