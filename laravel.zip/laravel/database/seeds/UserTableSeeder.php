<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Role;
class UserTableSeeder extends Seeder
{
  public function run()
  {
    $role_admin = Role::where('name', 'admin')->first();
    $role_authenticated  = Role::where('name', 'authenticated')->first();
    $role_agent  = Role::where('name', 'agent')->first();
    
    $admin = new User();
    $admin->name = 'admin';
    $admin->email = 'karunap@synapseindia.com';
    $admin->password = bcrypt('123456');
    $admin->save();
    $admin->roles()->attach($role_admin);
    
    $authenticated = new User();
    $authenticated->name = 'test';
    $authenticated->email = 'test@test.com';
    $authenticated->password = bcrypt('123456');
    $authenticated->save();
    $authenticated->roles()->attach($role_authenticated);
    
    $agent = new User();
    $agent->name = 'Test Agent';
    $agent->email = 'test-agent@test.com';
    $agent->password = bcrypt('123456');
    $agent->save();
    $agent->roles()->attach($role_agent);
  }
}
