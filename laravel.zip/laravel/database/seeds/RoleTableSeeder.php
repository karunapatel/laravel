<?php
use Illuminate\Database\Seeder;
use App\Role;

class RoleTableSeeder extends Seeder
{
  public function run()
  {
    $role_admin = new Role();
    $role_admin->name = 'admin';
    $role_admin->description = 'Administrator User';
    $role_admin->save();
    
    $role_authenticated = new Role();
    $role_authenticated->name = 'authenticated';
    $role_authenticated->description = 'Authenticated User';
    $role_authenticated->save();
    
    $role_agent = new Role();
    $role_agent->name = 'agent';
    $role_agent->description = 'Agent User';
    $role_agent->save();
  }
}