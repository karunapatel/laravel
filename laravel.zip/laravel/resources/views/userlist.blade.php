@extends('layouts.app')

@section('content')
  <div class="container">
    <div class="flex-center">
      <div class="content">
          <div class="title m-b-md">
            Users List
          </div>
          <div class="d-grid">
            <table border="1">
              <thead>
                <tr><th style="text-align:center">User</th><th style="text-align:center">Role</th></tr>
              </thead>
              <tbody>
              @foreach($users as $user)
                <tr><td>{{ $user->name }} </td><td>{{ $user->roles->pluck('name') }}</td></td></tr>
              @endforeach
              </tbody>
            </table>
          </div>
      </div>
    </div>
  </div>
@endsection
