@extends('layouts.app')

@section('content')
  <div class="container">
    <div class="flex-center">
      <div class="content">
          <h1>Add New Listing</h1>
          @if(Session::has('success'))
             <div class="alert alert-success">
               {{ Session::get('success') }}
             </div>
          @endif
          
          {!! form($form) !!}
          
      </div>
    </div>
  </div>
@endsection