@extends('layouts.app')

@section('content')
  <div class="container">
    <div class="flex-center">
      <div class="content">
          <div class="title m-b-md">
            All Listings
          </div>
          <div class="d-grid">
            <table border="1">
              <thead>
                <tr><th style="text-align:center">Title</th><th style="text-align:center">Address</th><th style="text-align:center">Status</th><th style="text-align:center">Action</th></tr>
              </thead>
              <tbody>
              @foreach($datas as $data)
                <tr><td>{{ $data->title }} </td><td>{{ $data->street }}</td><td>{{ $data->listing_status }}</td><td><a href="/lc/listing/{{ $data->id }}/edit">Edit</a> | <a href="/lc/listing/{{ $data->id }}/detail">View</a></td></tr>
              @endforeach
              </tbody>
            </table>
          </div>
      </div>
    </div>
  </div>
@endsection
